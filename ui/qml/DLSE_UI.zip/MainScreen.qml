import QtQuick
import DesignTokens as Tokens

Rectangle {
    id: mainScreen

    height: 804
    width: 1298

    color: "#081624"

    Item {
        id: footer

        y: 777

        height: 27
        width: 1298

        Rectangle {
            id: footerBackground

            height: 27
            width: 1298

            color: "#0a1c2e"
        }
        Item {
            id: group_28

            x: 24
            y: 6

            height: 15
            width: 1252

            Text {
                id: license_Server_Status_

                x: 1060

                height: 15
                width: 147

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignLeft
                text: "License Server Status:"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
            Text {
                id: online

                x: 1212

                height: 15
                width: 41

                color: "#34d399"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignRight
                text: "online"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
            Image {
                id: line_3

                x: 160
                y: 1

                source: Qt.resolvedUrl("assets/line_3.png")
            }
            Item {
                id: group_26

                height: 15
                width: 141

                Text {
                    id: detected_Drones_

                    height: 15
                    width: 107

                    color: "#deceb9"
                    font.capitalization: Font.AllUppercase
                    font.family: "JetBrains Mono"
                    font.pixelSize: 11
                    font.weight: Font.Bold
                    horizontalAlignment: Text.AlignLeft
                    text: "Detected Drones:"
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignVCenter
                }
                Text {
                    id: element

                    x: 114

                    height: 15
                    width: 28

                    color: "#e2d5c8"
                    font.capitalization: Font.AllUppercase
                    font.family: "JetBrains Mono"
                    font.pixelSize: 11
                    font.weight: Font.Bold
                    horizontalAlignment: Text.AlignLeft
                    text: "1018"
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignVCenter
                }
            }
            Image {
                id: line_4

                x: 359
                y: 1

                source: Qt.resolvedUrl("assets/line_4.png")
            }
            Item {
                id: group_27

                x: 378

                height: 15
                width: 123

                Text {
                    id: status_

                    height: 15
                    width: 48

                    color: "#deceb9"
                    font.capitalization: Font.AllUppercase
                    font.family: "JetBrains Mono"
                    font.pixelSize: 11
                    font.weight: Font.Bold
                    horizontalAlignment: Text.AlignLeft
                    text: "Status:"
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignVCenter
                }
                Text {
                    id: sCANNING_

                    x: 50

                    height: 15
                    width: 74

                    color: "#e2d5c8"
                    font.capitalization: Font.AllUppercase
                    font.family: "JetBrains Mono"
                    font.pixelSize: 11
                    font.weight: Font.Bold
                    horizontalAlignment: Text.AlignLeft
                    text: "SCANNING..."
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignVCenter
                }
            }
            Item {
                id: group_25

                x: 179

                height: 15
                width: 161

                Text {
                    id: uniFi_Gateway_

                    height: 15
                    width: 94

                    color: "#deceb9"
                    font.capitalization: Font.AllUppercase
                    font.family: "JetBrains Mono"
                    font.pixelSize: 11
                    font.weight: Font.Bold
                    horizontalAlignment: Text.AlignLeft
                    text: "UniFi Gateway:"
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignVCenter
                }
                Text {
                    id: cONNECTED

                    x: 101

                    height: 15
                    width: 61

                    color: "#34d399"
                    font.capitalization: Font.AllUppercase
                    font.family: "JetBrains Mono"
                    font.pixelSize: 11
                    font.weight: Font.Bold
                    horizontalAlignment: Text.AlignLeft
                    text: "CONNECTED"
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }
    Rectangle {
        id: tableHeader

        y: 168

        height: 37
        width: 1298

        color: "transparent"

        Item {
            id: group_1

            height: 37
            width: 55

            Rectangle {
                id: rectangle_6

                height: 37
                width: 55

                color: "#0a1c2e"
            }
            Text {
                id: sel

                x: 12.87
                y: 4.83

                height: 25.74
                width: 31

                color: "#deceb9"
                font.family: "JetBrains Mono"
                font.pixelSize: 12
                font.weight: Font.Normal
                horizontalAlignment: Text.AlignHCenter
                text: "Sel"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_2

            x: 55

            height: 37
            width: 94

            Rectangle {
                id: rectangle_7

                height: 37
                width: 94

                color: "#0a1c2e"
            }
            Text {
                id: hostname

                x: 21
                y: 6.43

                height: 24.13
                width: 54

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "Hostname"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_3

            x: 149

            height: 37
            width: 94

            Rectangle {
                id: rectangle_8

                height: 37
                width: 94

                color: "#0a1c2e"
            }
            Text {
                id: iP

                x: 40
                y: 7

                height: 24.13
                width: 15

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "IP"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_7

            x: 243

            height: 37
            width: 125

            Rectangle {
                id: rectangle_9

                height: 37
                width: 125

                color: "#0a1c2e"
            }
            Text {
                id: activation_Status

                y: 6.43

                height: 24.13
                width: 126

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "Activation Status"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_4

            x: 368

            height: 37
            width: 95

            Rectangle {
                id: rectangle_10

                height: 37
                width: 95

                color: "#0a1c2e"
            }
            Text {
                id: eSP32_SYS_ID

                y: 6.43

                height: 24.13
                width: 96

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "ESP32 SYS ID"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_5

            x: 463

            height: 37
            width: 79

            Rectangle {
                id: rectangle_11

                height: 37
                width: 79

                color: "#0a1c2e"
            }
            Text {
                id: fC_SYS_ID

                y: 6.43

                height: 24.13
                width: 80

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "FC SYS ID"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_6

            x: 542

            height: 37
            width: 103

            Rectangle {
                id: rectangle_12

                height: 37
                width: 103

                color: "#0a1c2e"
            }
            Text {
                id: dLSE_Firmware

                y: 6.43

                height: 24.13
                width: 104

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "DLSE Firmware"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_8

            x: 645

            height: 37
            width: 64

            Rectangle {
                id: rectangle_13

                height: 37
                width: 64

                color: "#0a1c2e"
            }
            Text {
                id: rSSI_Drone

                y: 6.43

                height: 24.13
                width: 65

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "RSSI Drone"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
                wrapMode: Text.Wrap
            }
        }
        Item {
            id: group_13

            x: 709

            height: 37
            width: 64

            Rectangle {
                id: rectangle_14

                height: 37
                width: 64

                color: "#0a1c2e"
            }
            Text {
                id: rSSI_AP

                y: 6.43

                height: 24.13
                width: 65

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "RSSI AP"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_9

            x: 773

            height: 37
            width: 80

            Rectangle {
                id: rectangle_15

                height: 37
                width: 80

                color: "#0a1c2e"
            }
            Text {
                id: sSID

                y: 6.43

                height: 24.13
                width: 81

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "SSID"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_10

            x: 853

            height: 37
            width: 63

            Rectangle {
                id: rectangle_16

                height: 37
                width: 63

                color: "#0a1c2e"
            }
            Text {
                id: channel

                y: 6.43

                height: 24.13
                width: 64

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "Channel"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_20

            x: 916

            height: 37
            width: 63

            Rectangle {
                id: rectangle_17

                height: 37
                width: 63

                color: "#0a1c2e"
            }
            Text {
                id: battery

                y: 6.43

                height: 24.13
                width: 64

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "Battery"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_21

            x: 979

            height: 37
            width: 80

            Rectangle {
                id: rectangle_18

                height: 37
                width: 80

                color: "#0a1c2e"
            }
            Text {
                id: gateway_IP

                y: 6.43

                height: 24.13
                width: 81

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "Gateway IP"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_22

            x: 1059

            height: 37
            width: 80

            Rectangle {
                id: rectangle_19

                height: 37
                width: 80

                color: "#0a1c2e"
            }
            Text {
                id: subnetMask

                y: 6.43

                height: 24.13
                width: 81

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "SubnetMask"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
        Item {
            id: group_23

            x: 1139

            height: 37
            width: 63

            Rectangle {
                id: rectangle_20

                height: 37
                width: 63

                color: "#0a1c2e"
            }
            Text {
                id: fC_Power_State

                y: 6.43

                height: 24.13
                width: 64

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "FC Power State "
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
                wrapMode: Text.Wrap
            }
        }
        Item {
            id: group_24

            x: 1202

            height: 37
            width: 96

            Rectangle {
                id: rectangle_21

                height: 37
                width: 96

                color: "#0a1c2e"
            }
            Text {
                id: fC_ARM_State

                y: 6.43

                height: 24.13
                width: 97

                color: "#deceb9"
                font.capitalization: Font.AllUppercase
                font.family: "JetBrains Mono"
                font.pixelSize: 11
                font.weight: Font.Bold
                horizontalAlignment: Text.AlignHCenter
                text: "FC ARM State"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
    }
    Rectangle {
        id: tableControls

        y: 137

        height: 21
        width: 1298

        color: "transparent"

        Rectangle {
            id: tableSelectionButtons

            x: 20
            y: 2.50

            height: 16
            width: 120

            color: "transparent"

            ControlsCheckbox {
                id: controlsCheckbox

                width: 86

                check_1: ControlsCheckbox.Check.Check_Off
                labelText: "Select All"
                labelWidth: 55
                status_1: ControlsCheckbox.Status.Status_Default
            }
            ControlsCheckbox {
                id: controlsCheckbox_1

                x: 93

                width: 105

                check_1: ControlsCheckbox.Check.Check_Off
                labelText: "Select Visible"
                labelWidth: 76
                status_1: ControlsCheckbox.Status.Status_Default
            }
        }
        TextButton {
            id: textButton

            x: 574
            y: 1

            configure_ColumnsTextButtonFontUnderline: false
            configure_ColumnsTextButtonWrapMode: Text.NoWrap
            eigenschaft_2: TextButton.Eigenschaft_1.Eigenschaft_1_Standard
        }
        ControlsSwitch {
            id: listMatrixSwitch

            x: 1157

            check_1: ControlsSwitch.Check.Check_Off
            status_1: ControlsSwitch.Status.Status_Default
        }
    }
    Rectangle {
        id: frame_16

        height: 128
        width: 1299

        color: "transparent"

        Rectangle {
            id: headerBar

            height: 64
            width: 1299

            color: "transparent"

            Rectangle {
                id: frame_12

                x: 22

                height: 63
                width: 1277

                color: "transparent"

                Rectangle {
                    id: frame_13

                    y: 20

                    height: 23
                    width: 373

                    color: "transparent"

                    Image {
                        id: droneBridgeLogo_1

                        y: 4.50

                        source: Qt.resolvedUrl("assets/droneBridgeLogo_1.png")
                    }
                    Item {
                        id: modeIndicator

                        x: 146

                        height: 23
                        width: 125

                        Rectangle {
                            id: rectangle_3

                            height: 23
                            width: 125

                            color: "#35322e"
                            radius: Tokens.Collection_1.numbers.radius
                        }
                        Text {
                            id: standalone_Mode

                            x: 12
                            y: 6

                            height: 10.45
                            width: 102

                            color: "#ff8e00"
                            font.capitalization: Font.AllUppercase
                            font.family: "Geist"
                            font.pixelSize: 10
                            font.weight: Font.Bold
                            horizontalAlignment: Text.AlignLeft
                            text: "Standalone Mode"
                            textFormat: Text.PlainText
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                    Text {
                        id: versionLabel

                        x: 295
                        y: 5

                        height: 13
                        width: 79

                        color: "#87deceb9"
                        font.family: "JetBrains Mono"
                        font.letterSpacing: -0.50
                        font.pixelSize: 10
                        font.weight: Font.Normal
                        horizontalAlignment: Text.AlignRight
                        text: "Version: 1.1.0"
                        textFormat: Text.PlainText
                        verticalAlignment: Text.AlignVCenter
                    }
                }
                Searchbar {
                    id: searchbar

                    x: 517
                    y: 16

                    eigenschaft_2: Searchbar.Eigenschaft_1.Eigenschaft_1_Standard
                }
                Rectangle {
                    id: mainTabs

                    x: 875

                    height: 63
                    width: 402

                    color: "transparent"

                    Image {
                        id: line_9

                        source: Qt.resolvedUrl("assets/line_9.png")
                    }
                    MainTab {
                        id: mainTab

                        eigenschaft_2: MainTab.Eigenschaft_1.Eigenschaft_1_Standard
                    }
                    Image {
                        id: line_7

                        x: 177

                        source: Qt.resolvedUrl("assets/line_7.png")
                    }
                    MainTab {
                        id: mainTab_1

                        x: 177

                        eigenschaft_2: MainTab.Eigenschaft_1.Eigenschaft_1_Standard
                    }
                    Image {
                        id: line_8

                        x: 354

                        source: Qt.resolvedUrl("assets/line_8.png")
                    }
                    SettingsTab {
                        id: settingsTab

                        x: 354

                        eigenschaft_2: SettingsTab.Eigenschaft_1.Eigenschaft_1_Standard
                    }
                }
            }
            Image {
                id: line_1

                y: 63

                source: Qt.resolvedUrl("assets/line_1.png")
            }
        }
        Rectangle {
            id: mainButtonBar

            x: 19.63
            y: 81

            height: 30
            width: 1279.37

            color: "transparent"

            Item {
                id: group_38

                height: 30
                width: 190

                Scan_Button {
                    id: scan_Button

                    _vectorVisible: true
                    clip: true
                    eigenschaft_2: Scan_Button.Eigenschaft_1.Eigenschaft_1_Standard
                    text_LabelVisible: true
                }
                ScanSettingsButton {
                    id: scanSettingsButton

                    x: 154

                    eigenschaft_2: ScanSettingsButton.Eigenschaft_1.Eigenschaft_1_Standard
                }
            }
            Rectangle {
                id: frame_7

                x: 707

                height: 29
                width: 572.37

                color: "transparent"

                ImageButton {
                    id: rebootDevicesButton

                    x: 14

                    width: 148.79

                    clip: true
                    eigenschaft_2: ImageButton.Eigenschaft_1.Eigenschaft_1_Standard
                    text_LabelText: "Reboot Devices"
                    text_LabelWidth: 99
                }
                ImageButton {
                    id: firmwareOTA

                    x: 174.79

                    width: 192.79

                    clip: true
                    eigenschaft_2: ImageButton.Eigenschaft_1.Eigenschaft_1_Standard
                    text_LabelText: "OTA Firmware Upgrade"
                    text_LabelWidth: 143
                }
                ImageButton {
                    id: imageButton

                    x: 379.58

                    clip: true
                    eigenschaft_2: ImageButton.Eigenschaft_1.Eigenschaft_1_Standard
                }
            }
        }
        Image {
            id: line_2

            y: 127

            source: Qt.resolvedUrl("assets/line_2.png")
        }
    }
}