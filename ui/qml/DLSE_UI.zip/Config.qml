import QtQuick

Rectangle {
    id: config

    height: 650
    width: 355

    border.color: "#2e3a47"
    border.width: 1
    color: "#0a1c2e"

    Rectangle {
        id: configurationFrameHeader

        x: 1
        y: 1

        height: 29
        width: 353

        color: "#0a1c2e"

        Rectangle {
            id: frame_36

            x: 1
            y: 3

            height: 24
            width: 132

            color: "transparent"

            ArrowRightImageButton {
                id: arrowRightImageButton

                clip: true
                eigenschaft_2: ArrowRightImageButton.Eigenschaft_1.Eigenschaft_1_Standard
            }
            Text {
                id: eSP32_Configuration

                x: 27
                y: 5.50

                height: 13
                width: 106

                color: "#deceb9"
                font.family: "JetBrains Mono"
                font.letterSpacing: -0.50
                font.pixelSize: 10
                font.weight: Font.Normal
                horizontalAlignment: Text.AlignLeft
                text: "ESP32 Configuration"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignVCenter
            }
        }
    }
    Rectangle {
        id: settingsTabs

        x: 1
        y: 30

        height: 40
        width: 355

        color: "transparent"

        TabSmall {
            id: tabSmall

            width: 109

            eigenschaft_2: TabSmall.Eigenschaft_1.Eigenschaft_1_Standard
            settingsWidth: 110
        }
        TabSmall {
            id: tabSmall_1

            x: 109

            width: 126

            eigenschaft_2: TabSmall.Eigenschaft_1.Eigenschaft_1_Standard
            settingsText: "Web-Interface"
            settingsWidth: 127
        }
        TabSmall {
            id: tabSmall_2

            x: 235

            width: 118

            eigenschaft_2: TabSmall.Eigenschaft_1.Eigenschaft_1_Standard
            settingsText: "Metrics"
            settingsWidth: 119
        }
    }
    OrangeTransparentButton {
        id: applyChangesButton

        x: 20
        y: 601

        eigenschaft_2: OrangeTransparentButton.Eigenschaft_1.Eigenschaft_1_Eigenschaft4
    }
    OrangeTransparentButton {
        id: exportSettingsButton

        x: 20
        y: 553

        apply_ChangesText: "Export Settings"
        eigenschaft_2: OrangeTransparentButton.Eigenschaft_1.Eigenschaft_1_Eigenschaft4
    }
}