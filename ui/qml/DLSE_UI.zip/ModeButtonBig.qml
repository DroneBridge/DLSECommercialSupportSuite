import QtQuick
import DesignTokens as Tokens

Rectangle {
    enum Eigenschaft_1 { Eigenschaft_1_Standard, Eigenschaft_1_Variante2, Eigenschaft_1_Variante3}

    id: modeButtonBig

    property int eigenschaft_2: ModeButtonBig.Eigenschaft_1.Eigenschaft_1_Standard

    height: 180
    width: 400

    border.color: "#f0f0f0"
    border.width: 1
    color: "transparent"
    radius: Tokens.Collection_1.numbers.radius

    states: [
        State {
            name: "Eigenschaft 1=Standard"
            when: modeButtonBig.eigenschaft_2 === ModeButtonBig.Eigenschaft_1.Eigenschaft_1_Standard
    
            PropertyChanges {
                color: "transparent"
                target: modeButtonBig
            }
        },
        State {
            name: "Eigenschaft 1=Variante2"
            when: modeButtonBig.eigenschaft_2 === ModeButtonBig.Eigenschaft_1.Eigenschaft_1_Variante2
    
            PropertyChanges {
                color: "#081624"
                target: modeButtonBig
            }
        },
        State {
            name: "Eigenschaft 1=Variante3"
            when: modeButtonBig.eigenschaft_2 === ModeButtonBig.Eigenschaft_1.Eigenschaft_1_Variante3
    
            PropertyChanges {
                color: "#0a1c2e"
                target: modeButtonBig
            }
        }
    ]

    Text {
        id: direct_Standalone

        x: 24
        y: 24

        height: 21
        width: 139

        color: "#f0f0f0"
        font.family: "Geist"
        font.pixelSize: 16
        font.weight: Font.DemiBold
        horizontalAlignment: Text.AlignHCenter
        text: "Direct Standalone"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignTop
    }
    Text {
        id: the_application_tries_to_detect_and_directly_con

        x: 24
        y: 61

        height: 61
        width: 353

        color: "#f0f0f0"
        font.family: "Inter"
        font.pixelSize: 12
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        text: "The application tries to detect and directly connect to each of your drones.\nUse for updating, activating and configuration of a DLSE drone fleet."
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignTop
        wrapMode: Text.Wrap
    }
}