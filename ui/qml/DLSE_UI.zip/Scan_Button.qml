import QtQuick
import DesignTokens as Tokens
import QtQuick.Shapes

Rectangle {
    enum Eigenschaft_1 { Eigenschaft_1_Standard, Eigenschaft_1_Variante2, Eigenschaft_1_Variante3, Eigenschaft_1_Variante4}

    id: scan_Button

    property alias _vectorVisible: _vector.visible
    property alias text_LabelVisible: text_Label.visible

    property int eigenschaft_2: Scan_Button.Eigenschaft_1.Eigenschaft_1_Standard

    height: 30
    width: 154

    border.color: "#2e3a47"
    border.width: 1
    bottomLeftRadius: Tokens.Collection_1.numbers.radius
    clip: true
    color: "#1ae2d5c8"
    topLeftRadius: Tokens.Collection_1.numbers.radius

    states: [
        State {
            name: "Eigenschaft 1=Standard"
            when: scan_Button.eigenschaft_2 === Scan_Button.Eigenschaft_1.Eigenschaft_1_Standard
    
            PropertyChanges {
                width: 154
    
                target: scan_Button
            }
            PropertyChanges {
                height: 30
    
                target: scan_Button
            }
            PropertyChanges {
                color: "#1ae2d5c8"
                target: scan_Button
            }
            PropertyChanges {
                border.width: 1
                target: scan_Button
            }
            PropertyChanges {
                border.color: "#2e3a47"
                target: scan_Button
            }
            PropertyChanges {
                target: scan_Button
                topLeftRadius: Tokens.Collection_1.numbers.radius
            }
            PropertyChanges {
                bottomLeftRadius: Tokens.Collection_1.numbers.radius
                target: scan_Button
            }
            PropertyChanges {
                target: _vector
                visible: true
            }
            PropertyChanges {
                target: _vector
                visible: true
            }
            PropertyChanges {
                target: text_Label
                visible: true
            }
            PropertyChanges {
                target: text_Label
                visible: true
            }
        },
        State {
            name: "Eigenschaft 1=Variante2"
            when: scan_Button.eigenschaft_2 === Scan_Button.Eigenschaft_1.Eigenschaft_1_Variante2
    
            PropertyChanges {
                width: 154
    
                target: scan_Button
            }
            PropertyChanges {
                height: 30
    
                target: scan_Button
            }
            PropertyChanges {
                color: "#1ae2d5c8"
                target: scan_Button
            }
            PropertyChanges {
                border.width: 1
                target: scan_Button
            }
            PropertyChanges {
                border.color: "#deceb9"
                target: scan_Button
            }
            PropertyChanges {
                target: scan_Button
                topLeftRadius: Tokens.Collection_1.numbers.radius
            }
            PropertyChanges {
                bottomLeftRadius: Tokens.Collection_1.numbers.radius
                target: scan_Button
            }
            PropertyChanges {
                target: _vector
                visible: true
            }
            PropertyChanges {
                target: text_Label
                visible: true
            }
        },
        State {
            name: "Eigenschaft 1=Variante3"
            when: scan_Button.eigenschaft_2 === Scan_Button.Eigenschaft_1.Eigenschaft_1_Variante3
    
            PropertyChanges {
                width: 154
    
                target: scan_Button
            }
            PropertyChanges {
                height: 30
    
                target: scan_Button
            }
            PropertyChanges {
                color: "#0a1c2e"
                target: scan_Button
            }
            PropertyChanges {
                border.width: 1
                target: scan_Button
            }
            PropertyChanges {
                border.color: "#deceb9"
                target: scan_Button
            }
            PropertyChanges {
                target: scan_Button
                topLeftRadius: Tokens.Collection_1.numbers.radius
            }
            PropertyChanges {
                bottomLeftRadius: Tokens.Collection_1.numbers.radius
                target: scan_Button
            }
            PropertyChanges {
                target: _vector
                visible: true
            }
            PropertyChanges {
                target: text_Label
                visible: true
            }
        },
        State {
            name: "Eigenschaft 1=Variante4"
            when: scan_Button.eigenschaft_2 === Scan_Button.Eigenschaft_1.Eigenschaft_1_Variante4
    
            PropertyChanges {
                width: 24
    
                target: scan_Button
            }
            PropertyChanges {
                height: 24
    
                target: scan_Button
            }
            PropertyChanges {
                color: "transparent"
                target: scan_Button
            }
            PropertyChanges {
                border.width: 0
                target: scan_Button
            }
            PropertyChanges {
                border.color: "white"
                target: scan_Button
            }
            PropertyChanges {
                target: scan_Button
                topLeftRadius: ""
            }
            PropertyChanges {
                bottomLeftRadius: ""
                target: scan_Button
            }
            PropertyChanges {
                target: _vector
                visible: false
            }
            PropertyChanges {
                target: text_Label
                visible: false
            }
        }
    ]

    Shape {
        id: _vector

        x: 11
        y: 6

        height: 18
        width: 18

        visible: true

        ShapePath {
            id: _vector_ShapePath0

            fillColor: "#deceb9"
            fillRule: ShapePath.WindingFill
            joinStyle: ShapePath.MiterJoin
            strokeColor: "#00000000"
            strokeStyle: ShapePath.SolidLine
            strokeWidth: 0.03

            PathSvg {
                id: _vector_ShapePath0_PathSvg0

                path: "M 5.493000030517578 17.291500854492188 C 4.397500038146973 16.819167518615725 3.444499969482422 16.178166389465332 2.6340000152587892 15.368499755859375 C 1.8235000610351564 14.558833122253418 1.1819165229797364 13.606666946411133 0.7092498779296875 12.512000274658204 C 0.23641653060913087 11.417500305175782 0 10.247916793823242 0 9.003250122070312 C 0 7.758750152587891 0.23616657257080076 6.588665962219238 0.7084999084472656 5.492999267578125 C 1.1808332443237304 4.39749927520752 1.8218332290649415 3.444499588012696 2.6314998626708985 2.6339996337890628 C 3.4411664962768556 1.82349967956543 4.393333053588868 1.1819165229797364 5.487999725341798 0.7092498779296875 C 6.58249969482422 0.23641653060913087 7.752083206176758 0 8.996749877929688 0 C 10.24124984741211 0 11.411334037780762 0.23616733551025393 12.507000732421876 0.7085006713867188 C 13.602500724792481 1.1808340072631838 14.555500411987305 1.821833610534668 15.366000366210939 2.631500244140625 C 16.17650032043457 3.441166877746582 16.818083477020267 4.393333816528321 17.290750122070314 5.4880004882812505 C 17.76358346939087 6.582500457763673 18 7.752083206176758 18 8.996749877929688 C 18 10.24124984741211 17.763832664489744 11.411333274841308 17.29149932861328 12.506999969482422 C 16.819165992736817 13.602499961853027 16.178166389465332 14.555500411987305 15.368499755859375 15.366000366210939 C 14.558833122253418 16.17650032043457 13.60666618347168 16.818083477020267 12.51199951171875 17.290750122070314 C 11.417499542236328 17.76358346939087 10.247916793823242 18 9.003250122070312 18 C 7.758750152587891 18 6.588666725158691 17.76383419036865 5.493000030517578 17.291500854492188 Z M 9 17 C 10.016666698455811 17 10.974332904815673 16.822083950042725 11.872999572753907 16.466250610351562 C 12.771832942962646 16.11058394908905 13.575666809082032 15.621166229248047 14.284500122070312 14.997999572753907 L 12.167250061035157 12.88074951171875 C 11.73525004386902 13.23074951171875 11.248250007629395 13.504833209514619 10.70625 13.702999877929688 C 10.164249992370607 13.900999879837038 9.595499992370605 14 9 14 C 7.611166667938233 14 6.430583000183106 13.51433334350586 5.458249664306641 12.543000030517579 C 4.486083030700684 11.571666717529297 4 10.39216651916504 4 9.004499816894532 C 4 7.616833114624024 4.485666656494141 6.435833835601807 5.456999969482422 5.461500549316407 C 6.428333282470703 4.487167263031006 7.607833480834961 4 8.995500183105468 4 C 10.383166885375976 4 11.564166164398195 4.486083793640137 12.538499450683595 5.458250427246094 C 13.512832736968996 6.430583763122559 14 7.611166667938233 14 9 C 14 9.598666667938232 13.9 10.168332958221436 13.700000000000001 10.708999633789062 C 13.500000000000002 11.249499654769897 13.225 11.737500333786011 12.875 12.17300033569336 L 14.992250061035158 14.290499877929689 C 15.615416717529298 13.5814998626709 16.10583279132843 12.778250312805177 16.463499450683596 11.880750274658205 C 16.82116611003876 10.983250236511232 17.000000000000004 10.022999954223632 17 9 C 17 6.766666603088378 16.225 4.875 14.675 3.325 C 13.125 1.7750000000000001 11.233333396911622 1 9 1 C 6.766666603088378 1 4.875 1.7750000000000001 3.325 3.325 C 1.7750000000000001 4.875 1 6.766666603088378 1 9 C 1 11.233333396911622 1.7750000000000001 13.125 3.325 14.675 C 4.875 16.225 6.766666603088378 17 9 17 Z M 9 13 C 9.451666688919067 13 9.887999629974367 12.925333547592164 10.308999633789064 12.776000213623048 C 10.729999637603761 12.626666879653932 11.109666228294374 12.421833109855653 11.447999572753908 12.161499786376954 L 9.25 9.963500213623048 C 9.209000000357628 9.979666879773141 9.167999663949013 9.989833577349783 9.126999664306641 9.994000244140626 C 9.08599966466427 9.99800024405122 9.045000091195107 10 9.004000091552735 10 C 8.73333342075348 10 8.49833312034607 9.900333547592163 8.298999786376953 9.701000213623047 C 8.099666452407837 9.50166687965393 8 9.26800000667572 8 9 C 8 8.73199999332428 8.099666452407837 8.49833312034607 8.298999786376953 8.298999786376953 C 8.49833312034607 8.099666452407837 8.73199999332428 8 9 8 C 9.26800000667572 8 9.50166687965393 8.099666452407837 9.701000213623047 8.298999786376953 C 9.900333547592163 8.49833312034607 10 8.730750155448913 10 8.99625015258789 C 10 9.044416818022729 9.99800024405122 9.090666514635085 9.994000244140626 9.134999847412109 C 9.989833577349783 9.17916651368141 9.979666116833688 9.221333119273186 9.963499450683594 9.261499786376953 L 12.155749511718751 11.45374984741211 C 12.41608283519745 11.115416502952577 12.62183290719986 10.738416767120361 12.772999572753907 10.322750091552734 C 12.924332904815675 9.9072500705719 13 9.46633334159851 13 9 C 13 7.9 12.608333349227907 6.958333349227906 11.825000000000001 6.175000000000001 C 11.041666650772095 5.391666650772096 10.1 5 9 5 C 7.9 5 6.958333349227906 5.391666650772096 6.175000000000001 6.175000000000001 C 5.391666650772096 6.958333349227906 5 7.9 5 9 C 5 10.1 5.391666650772096 11.041666650772095 6.175000000000001 11.825000000000001 C 6.958333349227906 12.608333349227907 7.9 13 9 13 Z"
            }
        }
    }
    Text {
        id: text_Label

        x: 37
        y: 6.50

        height: 17
        width: 107

        color: "#e2d5c8"
        font.family: "Geist"
        font.pixelSize: 13
        font.weight: Font.DemiBold
        horizontalAlignment: Text.AlignLeft
        text: "Scan for Devices"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignVCenter
        visible: true
    }
}