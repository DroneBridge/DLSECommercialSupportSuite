import QtQuick.Shapes
import QtQuick
import DesignTokens as Tokens

Shape {
    id: start

    height: 804
    width: 1298

    ShapePath {
        id: startShapePath

        strokeColor: "#000"
        strokeWidth: 0

        fillGradient: RadialGradient {
            id: gradientNode
        
            centerRadius: Math.max(start.width, start.height) * 1.0000000596046483
            centerX: start.width * 0.5000000298023242
            centerY: start.height * 0
            focalRadius: Math.max(start.width, start.height) * 0
            focalX: start.width * 0.5000000298023242
            focalY: start.height * 0
        
            GradientStop {
                color: "#ff01457c"
                position: 0
            }
            GradientStop {
                color: "#ff081119"
                position: 1
            }
        }

        PathRectangle {
            id: startPathRectangle

            x: 0
            y: 0

            height: start.height
            width: start.width
        }
    }
    Text {
        id: uniFi_mark_is_a_registered_trademark_or_trademar

        x: 377
        y: 767

        height: 17
        width: 545

        color: "#ffffff"
        font.family: "Roboto"
        font.letterSpacing: -0.11
        font.pixelSize: 11
        font.weight: Font.Light
        horizontalAlignment: Text.AlignHCenter
        lineHeight: 16.50
        lineHeightMode: Text.FixedHeight
        text: "UniFi mark is a registered trademark or trademark of Ubiquiti Networks, Inc. in the United States and other countries."
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignVCenter
    }
    Rectangle {
        id: frame_2

        x: 224
        y: -15.50

        height: 835
        width: 850

        clip: true
        color: "transparent"

        Image {
            id: droneBridgeLogo_foremost_white_1

            x: 305
            y: 176

            source: Qt.resolvedUrl("assets/droneBridgeLogo_foremost_white_1.png")
        }
        Rectangle {
            id: content

            x: 17
            y: 266

            height: 393
            width: 816

            color: "transparent"

            Rectangle {
                id: how_to_Connect_Layout

                x: 264

                height: 51
                width: 288

                color: "transparent"

                Text {
                    id: how_to_Connect

                    x: 50

                    height: 31
                    width: 189

                    color: "#f0f0f0"
                    font.family: "Geist"
                    font.pixelSize: 24
                    font.weight: Font.Bold
                    horizontalAlignment: Text.AlignHCenter
                    text: "How to Connect"
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignTop
                }
                Text {
                    id: choose_how_you_want_to_connect_to_your_drone_fle

                    y: 35

                    height: 16
                    width: 289

                    color: "#f0f0f0"
                    font.family: "Geist"
                    font.pixelSize: 12
                    font.weight: Font.Normal
                    horizontalAlignment: Text.AlignHCenter
                    text: "Choose how you want to connect to your drone fleet"
                    textFormat: Text.PlainText
                    verticalAlignment: Text.AlignTop
                }
            }
            Rectangle {
                id: frame_3

                y: 67

                height: 180
                width: 816

                color: "transparent"

                ModeButtonBig {
                    id: modeButtonBig

                    eigenschaft_2: ModeButtonBig.Eigenschaft_1.Eigenschaft_1_Standard
                }
                Rectangle {
                    id: frame_4

                    x: 416

                    height: 180
                    width: 400

                    border.color: "#f0f0f0"
                    border.width: 1
                    color: "transparent"
                    radius: Tokens.Collection_1.numbers.radius

                    Text {
                        id: monitor_via_Skybrush_Server

                        x: 24
                        y: 24

                        height: 21
                        width: 219

                        color: "#f0f0f0"
                        font.family: "Geist"
                        font.pixelSize: 16
                        font.weight: Font.DemiBold
                        horizontalAlignment: Text.AlignHCenter
                        text: "Monitor via Skybrush Server"
                        textFormat: Text.PlainText
                        verticalAlignment: Text.AlignTop
                    }
                    Text {
                        id: the_application_connects_to_the_Skybrush_Live_Se

                        x: 24
                        y: 61

                        height: 45
                        width: 353

                        color: "#f0f0f0"
                        font.family: "Inter"
                        font.pixelSize: 12
                        font.weight: Font.Normal
                        horizontalAlignment: Text.AlignLeft
                        text: "The application connects to the Skybrush Live Server to monitor your drones. No additional radio traffic is introduced.\nRecommended for monitoring your fleet during a live show."
                        textFormat: Text.PlainText
                        verticalAlignment: Text.AlignTop
                        wrapMode: Text.Wrap
                    }
                }
            }
            Rectangle {
                id: divider

                y: 263

                height: 1
                width: 816

                color: "transparent"

                Rectangle {
                    id: rectangle_11

                    height: 1
                    width: 816

                    color: "#e6e6e6"
                }
            }
            UniFiButton {
                id: uniFiButton

                x: 308
                y: 280

                eigenschaft_2: UniFiButton.Eigenschaft_1.Eigenschaft_1_Standard
            }
            Text {
                id: a_UniFi_Gateway_Connection_allows_for_quicker_de

                x: 162.50
                y: 345

                height: 48
                width: 492

                color: "#ffffff"
                font.family: "Geist"
                font.pixelSize: 12
                font.weight: Font.Normal
                horizontalAlignment: Text.AlignHCenter
                text: "A UniFi Gateway Connection allows for quicker detection of DLSE devices on the network. Additional features like access point RSSI and channel planning become available. Requires Ubiquity Access Points and at least one UniFi Gateway"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignTop
            }
        }
    }
    Text {
        id: droneBridge_DLSE_Commercial_Support_Suite

        x: 525
        y: 15

        height: 16
        width: 249

        color: "#e2d5c8"
        font.family: "Geist"
        font.pixelSize: 12
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignHCenter
        text: "DroneBridge DLSE Commercial Support Suite"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignVCenter
    }
}